<?php
include '../config.php';

$id = $_GET['id'];
$id = mysqli_real_escape_string($conn, $id); // Escape the value to prevent SQL injection

$roomdeletesql = "DELETE FROM staff WHERE id = '$id'"; // Add single quotes around $id

$result = mysqli_query($conn, $roomdeletesql);

header("Location: staff.php");
?>
