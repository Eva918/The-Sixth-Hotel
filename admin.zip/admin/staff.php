<?php
session_start();
include '../config.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- boot -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- fontowesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- sweet alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="./css/roombook.css">
    <title>The Sixth - Admin</title>
</head>

<body>
    <!-- guestdetailpanel -->

    <div id="guestdetailpanel">
      <!-- Modify the form -->
<form action="" method="POST" class="guestdetailpanelform">
    <div class="head">
        <h3>RESERVATION</h3>
        <i class="fa-solid fa-circle-xmark" onclick="adduserclose()"></i>
    </div>
    <div class="middle">
        <div class="guestinfo">
            <h4>Staff Information</h4>
            <input type="text" name="id" placeholder="Enter ID" required>
            <input type="text" name="Name" placeholder="Enter Full name" required>
            <input type="email" name="Email" placeholder="Enter Email" required>

            <?php
            $work = array("Reservationist", "Manager", "Cook", "Housekeeper", "Receptionist");
            ?>

            <select name="work" class="selectinput" required>
                <option value selected>Select your job</option>
                <?php
                foreach($work as $key => $value):
                    echo '<option value="'.$value.'">'.$value.'</option>';
                endforeach;
                ?>
            </select>
            <input type="text" name="phonenumber" placeholder="Enter Phone number" required>
        </div>

        <div class="line"></div>
    </div>
    <div class="footer">
        <button class="btn btn-success" name="guestdetailsubmit">Submit</button>
    </div>
</form>


             
      

       
<?php   
    if (isset($_POST['guestdetailsubmit'])) {
        $id = isset($_POST['id']) ? $_POST['id'] : "";
        $Name = isset($_POST['Name']) ? $_POST['Name'] : "";
        $Email = isset($_POST['Email']) ? $_POST['Email'] : "";
        $phonenumber = isset($_POST['phonenumber']) ? $_POST['phonenumber'] : "";
        $work = isset($_POST['work']) ? $_POST['work'] : "";

        if ($id == "" || $Name == "" || $Email == "" || $phonenumber == "") {
            echo "<script>swal({
                title: 'Fill the proper details',
                icon: 'error',
            });
            </script>";
        } else {
            $sta = "NotConfirm";
            $sql = "INSERT INTO staff(id, Name, Email, phonenumber, work) VALUES ('$id', '$Name', '$Email', '$phonenumber', '$work')";
            $result = mysqli_query($conn, $sql);

            if ($result) {
                echo "<script>swal({
                    title: 'Reservation successful',
                    icon: 'success',
                });
                </script>";
            } else {
                echo "<script>swal({
                        title: 'Something went wrong',
                        icon: 'error',
                    });
                </script>";
            }
        }
    }
?>
    </div>

    
    <!-- ================================================= -->
    <div class="searchsection">
        <input type="text" name="search_bar" id="search_bar" placeholder="search..." onkeyup="searchFun()">
        <button class="adduser" id="adduser" onclick="adduseropen()"><i class="fa-solid fa-bookmark"></i> Add</button>
        <form action="./exportdata.php" method="post">
            <button class="exportexcel" id="exportexcel" name="exportexcel" type="submit"><i class="fa-solid fa-file-arrow-down"></i></button>
        </form>
    </div>

    <div class="roombooktable" class="table-responsive-xl">
        <?php
            $stafftablesql = "SELECT * FROM staff";
            $staffresult = mysqli_query($conn, $stafftablesql);
            $nums = mysqli_num_rows($staffresult);
        ?>
        <table class="table table-bordered" id="table-data">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">phonenumber</th>
                    <th scope="col">work</th>
                    
                    <th scope="col">action</th>
                  
                    <!-- <th>Delete</th> -->
                </tr>
            </thead>

            <tbody>
<?php
while ($res = mysqli_fetch_array($staffresult)) {
?>
    <tr>
        <td><?php echo $res['id']; ?></td>
        <td><?php echo $res['name']; ?></td>
        <td><?php echo $res['email']; ?></td>
        <td><?php echo $res['phonenumber']; ?></td>
        <td><?php echo $res['work']; ?></td>
      
        <td class="action">
            <a href="staffedit.php?id=<?php echo $res['id']; ?>"><button class="btn btn-primary">Edit</button></a>
            <a href="staffdelete.php?id=<?php echo $res['id']; ?>"><button class='btn btn-danger'>Delete</button></a>
        </td>
    </tr>
<?php
}
?>
</tbody>


        </table>
    </div>
</body>
<script src="./javascript/roombook.js"></script>



</html>
